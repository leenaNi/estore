<?php

namespace App\Http\Controllers\Admin;

use Route;
use Input;
use App\Models\Product;
use App\Models\HasProducts;
use App\Models\Finish;
use App\Models\Fabric;
use App\Models\Category;
use App\Models\ProductType;
use App\Models\AttributeSet;
use App\Models\CatalogImage;
use App\Models\Attribute;
use App\Models\Conversion;
use App\Models\AttributeValue;
use App\Models\DownlodableProd;
use App\Models\GeneralSetting;
use App\Models\StockUpdateHistory;
use App\Http\Controllers\Controller;
use DB;
use Request;
use Response;
use App\Models\User;
use Session;
use App\Library\Helper;
use App\Classes\UploadHandler;
use Vsmoraes\Pdf\Pdf;
use DNS1D;
use DNS2D;

class StockController extends Controller {

    public function index() {
        $barcode = GeneralSetting::where('url_key', 'barcode')->get()->toArray()[0]['status'];
        $products = Product::where('is_individual', '=', '1')->where('stock', '!=', 0);
        if (!empty(Input::get('product_name'))) {
            $products = $products->where('product', 'like',"%". Input::get('product_name') . "%")->get();
            $productCount=$products->count();
        }else{
             $products = $products->sortable()->paginate(Config('constants.paginateNo'));
             $productCount=$products->total();
        }
       
        foreach ($products as $prd) {
            $prd->prodImage = asset(Config('constants.productImgPath') . @$prd->catalogimgs()->where("image_mode", 1)->first()->filename);
        }
        // return view(Config('constants.adminStockView') . '.index', compact('products', 'barcode'));

        $viewname = Config('constants.adminStockView') . '.index';
        $data = ['products' => $products, 'barcode' => $barcode ,'productCount' =>$productCount];
        return Helper::returnView($viewname, $data);
    }

    public function outOfStock() {
        $barcode = GeneralSetting::where('url_key', 'barcode')->get()->toArray()[0]['status'];
        $products = Product::where('is_individual', '=', '1');
        if (!empty(Input::get('product_name'))) {
            $products = $products->where('product', 'like', "%".Input::get('product_name') . "%")->where('stock', '=', 0)->get();
            $productCount=$products->count();
        }else{
           $products = $products->where('stock', '=', 0)->sortable()->paginate(Config('constants.paginateNo'));
           $productCount=$products->total();
        }

        
        foreach ($products as $prd) {
            $prd->prodImage = asset(Config('constants.productImgPath') . @$prd->catalogimgs()->where("image_mode", 1)->first()->filename);
        }
        // return view(Config('constants.adminStockView') . '.out-of-stock', compact('products', 'barcode'));
        $viewname = Config('constants.adminStockView') . '.out-of-stock';
        $data = ['products' => $products, 'barcode' => $barcode,'productCount'=>$productCount];
        return Helper::returnView($viewname, $data);
    }

    public function runningShort() {
        $barcode = GeneralSetting::where('url_key', 'barcode')->get()->toArray()[0]['status'];
        $products = Product::where('is_individual', '=', '1');
        if (!empty(Input::get('product_name'))) {
            $products = $products->where('product', 'like',"%".Input::get('product_name') . "%");
        }
        $getStockLimit = GeneralSetting::where('type', '7')->first();
        $stockLimitValue = json_decode($getStockLimit->details,TRUE);
                
        $products = $products->whereBetween('stock', ['1', $stockLimitValue['stock_limit']])->sortable()->paginate(Config('constants.paginateNo'));
        $productCount=$products->total();
        foreach ($products as $prd) {
            $prd->prodImage = asset(Config('constants.productImgPath') . @$prd->catalogimgs()->where("image_mode", 1)->first()->filename);
        }
        //return view(Config('constants.adminStockView') . '.running-short', compact('products', 'barcode'));
        $viewname = Config('constants.adminStockView') . '.running-short';
        $data = ['products' => $products, 'barcode' => $barcode,'productCount'=>$productCount];
        return Helper::returnView($viewname, $data);
    }

   public function updateProdStock() {
        $prodId = Input::get('prod-id');
        $stock = Input::get('stock');
        $prodUp = Product::find($prodId);
        $prodUp->stock = $stock;
        if ($prodUp->update()){
          Session::flash('msg' ,'Stock updated successfully.');
        return $data = ['status' => 'success', 'msg' => 'Stock updated succesfully'];
      
        }  else{
             Session::flash('message' ,'Oops something went wrong, Please try again later.');
        return $data = ['status' => 'error', 'msg' => 'Oops something went wrong, Please try again later!'];
       
        }
        } 

}
