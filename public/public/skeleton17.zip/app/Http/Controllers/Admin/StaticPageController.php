<?php

namespace App\Http\Controllers\Admin;

use Route;
use Input;
use App\Models\StaticPage;
use App\Models\Country;
use App\Models\Zone;
use App\Http\Controllers\Controller;
use App\Library\Helper;
use Session;
use Illuminate\Http\Request;
use DB;
use Validator;

class StaticPageController extends Controller {

    public function index() {
        $search = !empty(Input::get("page_name")) ? Input::get("page_name") : '';
        $search_fields = ['page_name'];

        if ($search != "") {
            $staticpageInfo = StaticPage::where(function($query) use($search_fields, $search) {
                        foreach ($search_fields as $field) {
                            $query->orWhere($field, "like", "%$search%");
                        }
                    })->get();
            $staticPageCount = $staticpageInfo->count();
        } else {
            $staticpageInfo = StaticPage::paginate(Config('constants.paginateNo'));
            $staticPageCount = $staticpageInfo->total();
        }
        $data = ['staticpageInfo' => $staticpageInfo, 'public_path' => 'public/Admin/uploads/staticpage/', 'staticPageCount' => $staticPageCount];
        $viewname = Config('constants.adminStaticPageView') . '.index';
        return Helper::returnView($viewname, $data);
    }

    public function add() {
        $page = new StaticPage();
        $action = route("admin.staticpages.save");
        $data = ['page' => $page, 'action' => $action, 'new' => '1', 'public_path' => 'public/Admin/uploads/staticpage/'];
        $viewname = Config('constants.adminStaticPageView') . '.addEdit';
        return Helper::returnView($viewname, $data);
    }

    public function edit() {
        $page = StaticPage::find(Input::get('id'));
        $action = route("admin.staticpages.update");
        $coutries = Country::where("status", 1)->orderBy('name')->pluck('name', 'id')->toArray();
        $states = Zone::orderBy('name')->get();
        $state = [];
        foreach ($states as $value) {
            $state[$value['id']] = $value['name'];
        }
        $data = ['page' => $page, 'action' => $action, 'state' => $state, 'coutries' => $coutries, 'new' => '0', 'public_path' => 'public/Admin/uploads/staticpage/'];
        $viewname = Config('constants.adminStaticPageView') . '.addEdit';
        return Helper::returnView($viewname, $data);
    }

    public function save(Request $request) {
        Validator::make($request->all(), [
            'page_name' => 'required',
            'description' => 'required',
            'url_key' => 'required',
            'link' => 'required|url',
            'image' => 'required|image',
                ], [
            'page_name.required' => 'The page name field is required.',
            'link.url' => 'Please enter valid url.',
            'link.required' => 'The link field is required.',
            'description.required' => 'The description field is required.',
            'image.image' => 'The image field required proper image file.',
            'image.required' => 'The image field is required.',
        ])->validate();

        $formData = $request->all();

        if (Input::hasFile('image')) {
            $destinationPath = 'public/Admin/uploads/staticpage/';
            $fileName = date("dmYHis") . "." . Input::File('image')->getClientOriginalExtension();
            $upload_success = Input::File('image')->move($destinationPath, $fileName);
        } else {
            $fileName = (!empty(Input::get('image')) ? Input::get('image') : '');
        }

        $formData['image'] = $fileName;
//dd($formData);
        $save = StaticPage::create($formData);
        $save->description = strip_tags(Input::get('description'));
        $save->update();

        Session::flash("msg", "Static page added successfully.");
        $viewname = Config('constants.adminStaticPageView') . '.index';
        $data = ['status' => '1'];
        return Helper::returnView($viewname, $data, $url = 'admin.staticpages.view');
    }

    public function update(Request $request) {
        //dd($request->all());
        Validator::make($request->all(), [

            'page_name' => 'required'
          //  'description' => 'required',
            // 'link' => 'required|url',
            ],[
            'page_name.required' => 'The page name field is required.'
          //  'description.required' => 'The description field is required.',

        ])->validate();

        $page = StaticPage::find($request->id);

       $page->page_name=Input::get('page_name');
        $page->link=Input::get('link');
         $page->description=  Input::get('description');
         $page->url_key=Input::get('url_key');
         $page->status=Input::get('status');
         $page->sort_order=Input::get('sort_order');
         $page->is_menu=Input::get('is_menu');
         $page->contact_details=json_encode(Input::get('details'));
           

//         if(Input::get('url_key')=='contact-us'){
//            $page->map_url=Input::get('map_url');  
//            $page->email_list=Input::get('email_list');
//         }
        // dd($formData);
        if (Input::hasFile('image')) {
            $destinationPath = 'public/Admin/uploads/staticpage/';
            $fileName = date("dmYHis") . "." . Input::File('image')->getClientOriginalExtension();
            $upload_success = Input::File('image')->move($destinationPath, $fileName);
            $formData['image'] = $fileName;
            $page->image = $fileName;
        }
        // dd($page);
        $page->update();
        // dd(Input::all());
        Session::flash("msg", "Static page updated successfully.");
        $viewname = Config('constants.adminStaticPageView') . '.index';
        $data = ['status' => '1', 'msg' => (Input::get('id') != '') ? 'Contact updated successfully.' : 'Contact added successfully.'];
        return Helper::returnView($viewname, $data, $url = 'admin.staticpages.view');
    }

    public function delete(Request $request) {
        $page = StaticPage::find($request->id);
        $page->delete();
        Session::flash("message", "Static page deleted successfully.");
        $data = ['status' => '1', 'msg' => 'Contact deleted successfully.'];
        $viewname = Config('constants.adminStaticPageView') . '.index';
        return Helper::returnView($viewname, $data, $url = 'admin.staticpages.view');
    }

    public function changeStatus(Request $request) {
        $contact = StaticPage::find($request->id);
        if ($contact->status == 1) {
            $contact->status = 0;
            $msg = "Static page disabled successfully.";
            Session::flash("message", $msg);
        } else {
            $contact->status = 1;
            $msg = "Static page enabled successfully.";
            Session::flash("msg", $msg);
        }
        $contact->update();

        $data = ['status' => '1', 'msg' => $msg];
        $viewname = Config('constants.adminStaticPageView') . '.index';
        return Helper::returnView($viewname, $data, $url = 'admin.staticpages.view');
    }

    public function getDescription(Request $request) {
        $page = StaticPage::find($request->page_id);
        return response()->json(['description' => $page->description]);
    }

}
