<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class OrderReturnOpenUnopen extends Model
{
    protected $table = 'order_return_open_unopen';
}
