<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class HasTaxes extends Model {

    protected $table = 'has_taxes';
   

}
