<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class HasIndustry extends Model
{
   protected $table = 'has_industries';
}
