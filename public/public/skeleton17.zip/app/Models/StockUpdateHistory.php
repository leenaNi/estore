<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class StockUpdateHistory extends Model
{
    protected $table = 'stock_update_history';
}
