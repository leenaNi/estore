<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class HasCategories extends Model {

    protected $table = 'has_categories';

}
