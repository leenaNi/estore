<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Stocknotify extends Model
{
    protected $table = "stocknotify";
}
