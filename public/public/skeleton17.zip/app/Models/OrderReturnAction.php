<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class OrderReturnAction extends Model
{
        protected $table = 'order_return_action';
}
