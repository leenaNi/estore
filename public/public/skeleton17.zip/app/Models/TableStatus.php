<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TableStatus extends Model {

    protected $table = 'occupancy_status';
   

}

