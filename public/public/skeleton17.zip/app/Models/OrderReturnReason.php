<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class OrderReturnReason extends Model
{
    protected $table = 'order_return_reason';
}
