<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class SliderMaster extends Model
{
    protected $table = 'slider_master';
}
