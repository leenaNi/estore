<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class AttributeType extends Model{

    protected $table = 'attribute_types';
    
   
}
