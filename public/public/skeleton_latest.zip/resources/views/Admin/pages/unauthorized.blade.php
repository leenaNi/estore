@extends('Admin.layouts.default')
@section('content')



        <div class="panel panel-default">

            <h3 class='text-center' style="color: red;">You are not authorized.</h3>


        </div>


@stop 