Hello {{$firstname}}
       Login password for veeSwipe app is: {{$password}}
   
