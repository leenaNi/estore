<script>
    window.close();
</script>
