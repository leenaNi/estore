@extends('Admin.layouts.default')
@section('content')

<section class="content-header">
    <h1>
        Products

    </h1>
    <ol class="breadcrumb">
        <li><a href="{{ route('admin.dashboard') }}"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Products</li>
        <li class="active">Add/Edit</li>
    </ol>
</section>


<div class="panel panel-default">

    <div class="panel-body">
        {!! Form::model($prod, ['method' => 'post', 'files'=> true, 'url' => $action , 'class' => 'form-horizontal' ]) !!}
        {!! Form::hidden('id',null) !!}
        {!! Form::hidden('updated_by', Auth::id()) !!}
        {!! Form::hidden("close","close") !!}
        <div class="row form-group col-md-12">

            <?php
            foreach ($attributes as $attribute):
                $required = $attribute['is_required'] ? "required" : NULL;
                switch ($attribute['attr_type']) {
                    case '1':
                        $options = NULL;
                        foreach ($attribute['attributeoptions'] as $val) {
                            $options[$val['option_value']] = $val['option_name'];
                        }
                        $multiple = $attribute['attr_type'] == 2 ? 'multiple' : '';
                        ?>
                        <div class="form-group col-md-4">
                            <div class="col-md-12">
                                {!! Form::label($attribute['attr'], $attribute['attr'],['class'=>'control-label '.$required]) !!}
                                {!! Form::select("attributes[".$attribute['id']."][attr_val]",$options,@$attribute['value'], ["class"=>'form-control' ,"placeholder"=>$attribute['placeholder'], $required ]) !!}
                                {!! Form::hidden("attributes[".$attribute['id']."][attr_type_id]",$attribute['attr_type']) !!}
                            </div>
                        </div>
                        <?php
                        break;
                    case '2':
                        $options = NULL;
                        foreach ($attribute['attributeoptions'] as $val) {
                            $options[$val['option_value']] = $val['option_name'];
                        }
                        ?>
                        <div class="form-group col-md-12">
                            <div class="col-md-12">
                                {!! Form::label($attribute['attr'], $attribute['attr'],['class'=>'control-label '.$required]) !!}
                                {!! Form::select("attributes[".$attribute['id']."][attr_val][]",$options,@$attribute['value'], ["class"=>'form-control', "multiple", $required]) !!}
                                {!! Form::hidden("attributes[".$attribute['id']."][attr_type_id]",$attribute['attr_type']) !!}
                            </div>
                        </div>
                        <?php
                        break;
                    case '3':
                        ?>
                        <div class="form-group col-md-4">
                            <div class="col-md-12">
                                {!! Form::label($attribute['attr'], $attribute['attr'],['class'=>'control-label '.$required]) !!}
                                {!! Form::text("attributes[".$attribute['id']."][attr_val]",@$attribute['value'], ["class"=>'form-control' ,"placeholder"=>$attribute['placeholder'], $required]) !!}
                                {!! Form::hidden("attributes[".$attribute['id']."][attr_type_id]",$attribute['attr_type']) !!}
                            </div>
                        </div>
                        <?php
                        break;
                    case '4':
                        ?>
                        <div class="form-group col-md-12">
                            <div class="col-md-12">
                                {!! Form::label($attribute['attr'], $attribute['attr'],['class'=>'control-label '.$required]) !!}
                            </div>
                            <div class="col-md-12">
                                @foreach ($attribute['attributeoptions'] as $val) 
                                {!! Form::radio("attributes[".$attribute['id']."][attr_val]", $val['option_value'], @$attribute['value'] == $val['option_value']? true:false, $attribute['is_required']=='1'? required:'' ) !!} {{$val['option_name']}} &nbsp;&nbsp;&nbsp;&nbsp;                                                    
                                @endforeach
                                {!! Form::hidden("attributes[".$attribute['id']."][attr_type_id]",$attribute['attr_type']) !!}
                            </div>
                        </div>
                        <?php
                        break;
                    case '5':
                        ?>
                        <div class="form-group col-md-12">
                            <div class="col-md-12">
                                {!! Form::label($attribute['attr'], $attribute['attr'],['class'=>'control-label '.$required]) !!}
                            </div>
                            <div class="col-md-12">
                                @foreach ($attribute['attributeoptions'] as $val) 
                                {!! Form::checkbox("attributes[".$attribute['id']."][attr_val][]",$val['option_value'], @in_array($val['option_value'], @$attribute['value'])? true:false ) !!} {{$val['option_name']}} &nbsp;&nbsp;&nbsp;&nbsp;
                                @endforeach
                                {!! Form::hidden("attributes[".$attribute['id']."][attr_type_id]",$attribute['attr_type']) !!}
                            </div>
                        </div>
                        <?php
                        break;
                    case '6':
                        ?>
                        <div class="form-group col-md-4">
                            <div class="col-md-12">
                                {!! Form::label($attribute['attr'], $attribute['attr'],['class'=>'control-label '.$required]) !!}
                                {!! Form::text("attributes[".$attribute['id']."][attr_val]",@$attribute['value'], ["class"=>'form-control datepicker' ,"placeholder"=>$attribute['placeholder'], $required]) !!}
                                {!! Form::hidden("attributes[".$attribute['id']."][attr_type_id]",$attribute['attr_type']) !!}
                            </div>
                        </div>
                        <?php
                        break;
                    case '7':
                        ?>
                        <div class="form-group col-md-4">
                            <div class="col-md-12">
                                {!! Form::label($attribute['attr'], $attribute['attr'],['class'=>'control-label '.$required]) !!}
                                {!! Form::text("attributes[".$attribute['id']."][attr_val]",@$attribute['value'], ["class"=>'form-control timepicker' ,"placeholder"=>$attribute['placeholder'], $required]) !!}
                                {!! Form::hidden("attributes[".$attribute['id']."][attr_type_id]",$attribute['attr_type']) !!}
                            </div>
                        </div>
                        <?php
                        break;
                    case '8':
                        ?>
                        <div class="form-group col-md-4">
                            <div class="col-md-12">
                                {!! Form::label($attribute['attr'], $attribute['attr'],['class'=>'control-label '.$required]) !!}
                                {!! Form::text("attributes[".$attribute['id']."][attr_val]",@$attribute['value'], ["class"=>'form-control datetimepicker' ,"placeholder"=>$attribute['placeholder'], $required]) !!}
                                {!! Form::hidden("attributes[".$attribute['id']."][attr_type_id]",$attribute['attr_type']) !!}
                            </div>
                        </div>
                        <?php
                        break;
                    case '9':
                        ?>
                        <div class="form-group col-md-4">
                            <div class="col-md-12">
                                {!! Form::label($attribute['attr'], $attribute['attr'],['class'=>'control-label '.$required]) !!}
                                {!! Form::text("attributes[".$attribute['id']."][attr_val]",@$attribute['value'], ["class"=>'form-control multidatepicker' ,"placeholder"=>$attribute['placeholder'], $required]) !!}
                                {!! Form::hidden("attributes[".$attribute['id']."][attr_type_id]",$attribute['attr_type']) !!}
                            </div>
                        </div>
                        <?php
                        break;
                    case '10':
                        ?>
                        <div class="form-group col-md-12">
                            <div class="col-md-4">
                                {!! Form::label($attribute['attr'], $attribute['attr'],['class'=>'control-label '.$required]) !!}
                                {!! Form::file("attributes[".$attribute['id']."][attr_val]",["class"=>'form-control' , $required]) !!}
                                {!! Form::hidden("attributes[".$attribute['id']."][attr_type_id]",$attribute['attr_type']) !!}
                                {!! Form::hidden("attributes[".$attribute['id']."][file_val]",@$attribute['value']) !!}
                            </div>
                            <div class="col-md-4" style="height: 50px;line-height: 50px;padding-top: 8px;">
                                <?php if (isset($attribute['value'])): ?>
                                    <a href="{{ asset('public/Uploads/product/')."/". $attribute['value'] }}" target="_BLANK"><i class="fa fa-file"></i></a>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php
                        break;
                    case '11':
                        ?>
                        <div class="form-group col-md-12">
                            <div class="col-md-4">
                                {!! Form::label($attribute['attr'], $attribute['attr'],['class'=>'control-label '.$required]) !!}
                                {!! Form::file("attributes[".$attribute['id']."][attr_val]",["class"=>'form-control' , $required, "accept"=>"image/x-png, image/jpeg"]) !!}
                                {!! Form::hidden("attributes[".$attribute['id']."][attr_type_id]",$attribute['attr_type']) !!}
                                {!! Form::hidden("attributes[".$attribute['id']."][image_val]",@$attribute['value']) !!}
                            </div>
                            <div class="col-md-4" style="height: 50px;line-height: 50px;padding-top: 8px;">
                                <?php if (isset($attribute['value'])): ?>
                                    <a href="{{ asset('public/Uploads/product/')."/". $attribute['value'] }}" target="_BLANK"><img src="{{asset('public/Uploads/product/')."/". $attribute['value'] }}" style="height: 50px; width: 50px;margin-right: 5px;" /></a>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php
                        break;
                    case '12':
                        ?>
                        <div class="form-group col-md-12">
                            <div class="col-md-12">
                                {!! Form::label($attribute['attr'], $attribute['attr'],['class'=>'control-label '.$required]) !!}
                                {!! Form::textarea("attributes[".$attribute['id']."][attr_val]",@$attribute['value'], ["class"=>'form-control editor' ,"placeholder"=>$attribute['placeholder'], $required]) !!}
                                {!! Form::hidden("attributes[".$attribute['id']."][attr_type_id]",$attribute['attr_type']) !!}
                            </div>
                        </div>
                        <?php
                        break;
                    case '13':
                        ?>
                        <div class="form-group col-md-12">
                            <div class="col-md-12">
                                {!! Form::label($attribute['attr'], $attribute['attr'],['class'=>'control-label '.$required]) !!}
                                {!! Form::textarea("attributes[".$attribute['id']."][attr_val]",@$attribute['value'], ["class"=>'form-control' ,"placeholder"=>$attribute['placeholder'], $required]) !!}
                                {!! Form::hidden("attributes[".$attribute['id']."][attr_type_id]",$attribute['attr_type']) !!}
                            </div>
                        </div>
                        <?php
                        break;
                    case '14':
                        ?>
                        <div class="form-group col-md-4">
                            <div class="col-md-12">
                                {!! Form::label($attribute['attr'], $attribute['attr'],['class'=>'control-label '.$required]) !!}
                                {!! Form::number("attributes[".$attribute['id']."][attr_val]",@$attribute['value'], ["class"=>'form-control' ,"placeholder"=>$attribute['placeholder'], $required]) !!}
                                {!! Form::hidden("attributes[".$attribute['id']."][attr_type_id]",$attribute['attr_type']) !!}
                            </div>
                        </div>
                        <?php
                        break;
                    case '15':
                        ?>
                        <div class="form-group col-md-4">
                            <div class="col-md-12">
                                {!! Form::label($attribute['attr'], $attribute['attr'],['class'=>'control-label '.$required]) !!}
                                {!! Form::select("attributes[".$attribute['id']."][attr_val]",['Yes'=>'Yes', 'No'=>'No'] ,@$attribute['value'], ["class"=>'form-control' ,"placeholder"=>$attribute['placeholder'], $required]) !!}
                                {!! Form::hidden("attributes[".$attribute['id']."][attr_type_id]",$attribute['attr_type']) !!}
                            </div>
                        </div>
                        <?php
                        break;
                    case '16':
                        ?>
                        <div class="form-group col-md-12">
                            <div class="col-md-4">
                                {!! Form::label($attribute['attr'], $attribute['attr'],['class'=>'control-label '.$required]) !!}
                                {!! Form::file("attributes[".$attribute['id']."][attr_val][]", ["class"=>'form-control' ,"multiple", $required]) !!}
                                {!! Form::hidden("attributes[".$attribute['id']."][attr_type_id]",$attribute['attr_type']) !!}
                                {!! Form::hidden("attributes[".$attribute['id']."][file_multi_val]",@$attribute['value']) !!}
                            </div>
                            <div class="col-md-8" style="height: 50px;line-height: 50px;padding-top: 8px;">
                                <?php
                                if (isset($attribute['value'])):
                                    foreach (json_decode($attribute['value']) as $file):
                                        ?>
                                        <a href="{{ asset('public/Uploads/product/')."/". $file }}" target="_BLANK"><i class="fa fa-file"></i></a>
                                        <?php
                                    endforeach;
                                endif;
                                ?>
                            </div>
                        </div>
                        <?php
                        break;
                    case '17':
                        ?>
                        <div class="form-group col-md-12">
                            <div class="col-md-4">
                                {!! Form::label($attribute['attr'], $attribute['attr'],['class'=>'control-label '.$required]) !!}
                                {!! Form::file("attributes[".$attribute['id']."][attr_val][]", ["class"=>'form-control' ,"multiple", $required, "accept"=>"image/x-png, image/jpeg"]) !!}
                                {!! Form::hidden("attributes[".$attribute['id']."][attr_type_id]",$attribute['attr_type']) !!}
                                {!! Form::hidden("attributes[".$attribute['id']."][image_multi_val]",@$attribute['value']) !!}
                            </div>
                            <div class="col-md-8" style="height: 50px;line-height: 50px;padding-top: 8px;">
                                <?php
                                if (isset($attribute['value'])):
                                    foreach (json_decode($attribute['value']) as $image):
                                        ?>
                                        <a href="{{ asset('public/Uploads/product/')."/". $image }}" target="_BLANK"><img src="{{asset('public/Uploads/product/')."/". $image }}" style="height: 50px; width: 50px;margin-right: 5px;" /></a>
                                        <?php
                                    endforeach;
                                endif;
                                ?>
                            </div>
                        </div>
                        <?php
                        break;
                    default:
                        ?>
                        <div class="form-group col-md-4">
                            <div class="col-md-12">
                                {!! Form::label($attribute['attr'], $attribute['attr'],['class'=>'control-label '.$required]) !!}
                                {!! Form::select("attributes[".$attribute['id']."][attr_val]",$options,@$attribute['value'], ["class"=>'form-control' ,"placeholder"=>$attribute['placeholder'], $required ]) !!}
                                {!! Form::hidden("attributes[".$attribute['id']."][attr_type_id]",$attribute['attr_type']) !!}
                            </div>
                        </div>
                        <?php
                        break;
                }
            endforeach;
            ?>
            <div class="col-md-2">
                {!! Form::label('Price', 'Price',['class'=>'control-label']) !!}
                {!! Form::number("price",$prod->price,["class"=>"form-control","min"=>"1"]) !!}
            </div>

            <div class="col-md-2">
                {!! Form::label('Stock', 'Stock',['class'=>'control-label']) !!}
                {!! Form::number("stock",$prod->stock,["class"=>"form-control","min"=>"1"]) !!}
            </div>



            <div class="col-md-2">
                {!! Form::label('is_avail', 'Availability',['class'=>'control-label']) !!}
                {!! Form::select("is_avail",['1'=>'Yes','0'=>'No'],$prod->is_avail,["class"=>"form-control"]) !!}
            </div>


        </div> 


        <div class="line line-dashed b-b line-lg pull-in"></div>

        <div class="form-group">
            <div class="col-sm-4 col-sm-offset-2">
                {!! Form::submit('Submit',["class" => "btn btn-primary"]) !!}
                {!! Form::close() !!}     


            </div>
        </div>
        </form>
    </div>
</div>

@stop 

@section('myscripts')

<script>
    $(document).ready(function () {
    });
    window.onunload = refreshParent;
    function refreshParent() {
        window.opener.location.reload();
    }
</script>
@stop