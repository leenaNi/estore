
 <!-- main-container -->
 <div class="main-container col2-right-layout abt-page notexit-page">
   <div class="main container bottom_margin_20">
     <div class="row">
       <section class="col-sm-12">
         <div class="col-main">
           <div class="static-contain">
             <h1 class="bigfnt">Your Store has expired.</h1>
             <div class="btn-404-box">
               <a  href="/" class="button">Go to Home</a>
               <a  href="/contact-us" class="button">Contact Us</a>
             </div>
           </div>
         </div>
       </section>
          
     </div>
   </div>
 </div>


