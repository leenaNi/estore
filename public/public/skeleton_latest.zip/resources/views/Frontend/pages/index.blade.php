
@extends('Frontend.layouts.default')
@section('content')
<a href='{{route('orderWithoutProduct')}}'>Order Without Product</a>
@stop
