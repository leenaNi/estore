


<a href="{{ route('home') }}">Home</a>
<div class="container">

    <h2 style="text-align: center;">Your transaction has been failed!</h2>
</div>




