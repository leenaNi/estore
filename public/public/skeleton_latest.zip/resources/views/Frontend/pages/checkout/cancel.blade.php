


<a href="{{ route('home') }}">Home</a>
<div class="container">

    <h2 style="text-align: center;">Your transaction has been canceled!</h2>
</div>











