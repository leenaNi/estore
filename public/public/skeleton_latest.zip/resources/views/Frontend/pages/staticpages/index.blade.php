@extends('Frontend.layouts.default')
@section('content')
	<div class="container">
	@php
		echo $description;
	@endphp
	</div>
@stop
