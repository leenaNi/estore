


 @extends('Frontend.layouts.default')
@section('content')
<?php echo html_entity_decode($contact->description) ?>
@stop