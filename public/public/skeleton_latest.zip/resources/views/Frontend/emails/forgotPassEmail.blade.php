<p>Dear {{$name}},</p>

<p>Your new password for the Cartini account {{$email}} has been set.
</p>

<p>Cheers,<br/>
    Team Cartini.<br/>
</p>


