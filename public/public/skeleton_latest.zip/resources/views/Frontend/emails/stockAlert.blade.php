
<p>Dear {!!$first_name !!},</p>

 <p> Stock of product {{ $product->product}}  become zero please update the product stock.
</p>

<p>Cheers,<br/>
   Team Kompanero.<br/>
</p>