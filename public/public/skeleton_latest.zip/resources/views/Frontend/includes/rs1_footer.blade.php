<!-- Footer
		============================================= -->
		<footer id="footer" class="dark transparant-black">

			

			<!-- Copyrights
			============================================= -->
			<div id="copyrights" class="copyrights-restro">

				<div class="container clearfix">

					<div class="col_half">
						Copyrights &copy; <?php echo date("Y"); ?> All Rights Reserved by Veestores.
					</div>

					<div class="col_half col_last tright">
						<div class="fright clearfix">
							<div class="copyrights-menu copyright-links restro-links nobottommargin">
								<a href="#">Home</a>/<a href="#">T &amp; C</a>/<a href="#">Disclaimer</a>/<a href="#">Contact</a>
							</div>
						</div>
					</div>

				</div>

			</div><!-- #copyrights end -->

		</footer><!-- #footer end -->