<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class Translation extends Model
{
    protected $table='translation';
}
