<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DynamicLayout extends Model {

    protected $table = 'dynamic_layout';
    public $timestamps = false;

}
