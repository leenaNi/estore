<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Sizechart extends Model {

    protected $table = 'sizechart';
    public $timestamps = false;

}
