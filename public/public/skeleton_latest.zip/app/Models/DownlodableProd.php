<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DownlodableProd extends Model {

    protected $table = 'downlodable_prods';
  

   

}
