<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class OrderReturnCashbackHistory extends Model
{
    protected $table = 'order_return_cashback_history';
}
