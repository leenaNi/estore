<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class HasCurrency extends Model
{
    protected $table = "has_currency";
}
