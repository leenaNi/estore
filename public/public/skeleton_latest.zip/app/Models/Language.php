<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class Language extends Model
{
    protected $table='language';
}
