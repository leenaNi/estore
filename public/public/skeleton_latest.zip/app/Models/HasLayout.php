<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class HasLayout extends Model
{
   protected $table = 'has_layouts';
}
